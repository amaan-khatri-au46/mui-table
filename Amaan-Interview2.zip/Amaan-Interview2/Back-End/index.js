const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const mongoose = require("mongoose");
const User = require("./routes/userRoute");
const Product = require("./routes/productRoute");

const app = express();

dotenv.config();

app.use(express.json());
app.use(cors());

const connect = async () => {
  try {
    await mongoose.connect(process.env.MONGO);
    console.log("connected To db");
  } catch (error) {
    throw error;
  }
};

app.use("/api", User);
app.use("/api", Product);

app.listen(process.env.PORT, () => {
  console.log(`app started at ${process.env.PORT}`);
  connect();
});
