const express = require("express");
const router = express.Router();
const {
  createProduct,
  getProducts,
  updateProduct,
  deleteProduct,
} = require("../controllers/productController");
const authMiddleware = require("../middleware/authMiddleware");

router.post("/product", authMiddleware, createProduct);
router.get("/products", authMiddleware, getProducts);
router.put("/product/:id", authMiddleware, updateProduct);
router.delete("/product/:id", authMiddleware, deleteProduct);

module.exports = router;
