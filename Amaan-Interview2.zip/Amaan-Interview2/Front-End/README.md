This Project Was Build Using Mern Stack 
Front-End Tech Used Is Mui 


Front-End - Start 
Step 1 : Create .env File And Copy Paste This - REACT_APP_BASE_URL = http://localhost:5000/api
Step 2 : npm i 
Step 3 : npm start 


Back-End - Start 
Step 1 : Create .env File And Copy And Paste This :
PORT = 5000
MONGO = mongodb+srv://AMAANKHATRI:amaankhatriqureshishaikh@amaankhatri.bfvdktd.mongodb.net/
JWT_SECRET = 80205e15f8c2854cb07a496889ac7cb3e8b39a745ec24bc4776cab4a902610a4


Step 2 : npm i 

Step 3 : npm Start 