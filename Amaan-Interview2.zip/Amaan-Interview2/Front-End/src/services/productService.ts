/** @format */

import ApiService from "./ApiService";


export async function apiGetProduct<T>() {
  return ApiService.fetchData<T>({
    url: "/products",
    method: "get",
  });
}

export async function apiCreateProduct<T>(data:any) {
  return ApiService.fetchData<T>({
    url: "/product",
    method: "post",
    data: data,
  });
}

export async function apiEditProduct<T>(id: string, data: any) {
  return ApiService.fetchData<T>({
    url: `/product/${id}`,
    method: "put",
    data: data,
  });
}

export async function apiDeleteProduct(productId: string) {
  return ApiService.fetchData<{ success: boolean }>({
    url: `/product/${productId}`,
    method: "delete",
  });
}

export async function apiGetLogin<T>(values: any) {
  return ApiService.fetchData<T>({
    url: '/login',
    method: 'post',
    data: values,
  });
}

export async function apiGetRegister<T>(values: any) {
  return ApiService.fetchData<T>({
    url: '/register',
    method: 'post',
    data: values,
  });
}


