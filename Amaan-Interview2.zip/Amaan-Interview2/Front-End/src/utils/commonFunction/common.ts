export const isAuthenticated = () => {
    return !!localStorage.getItem('token');
  };

  export function generateProductImages(count:any) {
    const productImages = [];
    for (let i = 1; i <= count; i++) {
      productImages.push(`/img/products/product-${i}.jpg`);
    }
    return productImages;
  }

  export function getUserDetails() {
    const userDetailsString = localStorage.getItem('userDetails');
    
    if (userDetailsString) {
      return JSON.parse(userDetailsString);
    } else {
      console.warn('No user details found in localStorage');
      return null;
    }
  }

  export function removeToken() {
    localStorage.removeItem('token');
  }


  export const Options = [
    { value: "All", label: "All" },
    { value: "Electronics", label: "Electronics" },
    { value: "Apparel", label: "Apparel and Accessories" },
    { value: "Home", label: "Home and Kitchen" },
    { value: "Beauty", label: "Beauty and Personal Care" },
    { value: "Health", label: "Health and Wellness" },
    { value: "Food", label: "Food and Beverages" },
    { value: "Toys", label: "Toys and Games" },
    { value: "Books", label: "Books and Media" },
    { value: "Sports", label: "Sports and Outdoors" },
    { value: "Automotive", label: "Automotive" },
    { value: "Office", label: "Office Supplies" },
    { value: "Pets", label: "Pet Supplies" },
    { value: "Kids", label: "Baby and Kids" },
    { value: "Jewelry", label: "Jewelry and Watches" },
    { value: "Crafts", label: "Crafts and DIY" },
];
