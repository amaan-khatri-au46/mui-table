export const routes = [
    { title: "Home", route: "/" },
    { title: "Product", route: "/product" },
    // Add more pages here if needed
  ];