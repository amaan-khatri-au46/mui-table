import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { apiCreateProduct, apiDeleteProduct, apiEditProduct, apiGetLogin, apiGetProduct, apiGetRegister } from "../../services/productService";


export interface Product {
  _id: string;
  title: string;
  price: number;
  description: string;
  category: string;
}

export interface ProductListState {
  loading : boolean
  productList : Product[]
  productTableList : Product[]
  openDrawer : boolean
  openDeleteDailog : boolean
  searchValue : string
  editRow : Product[]
  deleteRow : Product[]
  filterValue : Product[]
  viewProduct : boolean
  productDetail : Product[]
  filteredItem : string
}

export const SLICE_NAME = "productList";

export const fetchProduct = createAsyncThunk(
  `${SLICE_NAME}/fetchProduct`,
  async () => {
    const response = await apiGetProduct();
    return response?.data;
  }
);

export const createProduct = createAsyncThunk(
  `${SLICE_NAME}/createProduct`,
  async (data: any, { dispatch }) => {
    const response = await apiCreateProduct(data);
    dispatch(fetchProduct());
    return response?.data;
  }
);

export const editProduct = createAsyncThunk(
  `${SLICE_NAME}/editProduct`,
  async ({ id, data }: { id: string, data: any }, { dispatch }) => {
    const response = await apiEditProduct(id, data);
      dispatch(fetchProduct());
    return response?.data;
  }
);

export const deleteProduct = createAsyncThunk(
  `${SLICE_NAME}/deleteProduct`,
  async (productId: string, { dispatch }) => {
    const response = await apiDeleteProduct(productId);
      dispatch(fetchProduct());
      return response
    }
);

export const login = createAsyncThunk(
  `${SLICE_NAME}/login`,
  async ({ values }: { values: any }) => {
    const response:any = await apiGetLogin(values);
    const token = response?.data?.token;
    if (token) {
      localStorage.setItem("token", token);
    }
    return response?.data;
  }
);

export const register = createAsyncThunk(
  `${SLICE_NAME}/register`,
  async ({ values }: { values: any }) => {
    const response = await apiGetRegister(values);
    return response?.data;
  }
);


const initialState: ProductListState = {
  loading : false,
  productList : [],
  productTableList : [],
  openDrawer : false,
  openDeleteDailog : false,
  searchValue : '',
  editRow : [],
  deleteRow : [],
  filterValue : [],
  viewProduct : false,
  productDetail : [],
  filteredItem : ''
};

const productListSlice = createSlice({
  name: SLICE_NAME,
  initialState,
  reducers: {
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    setDrawer : (state , action ) => {
      state.openDrawer = action.payload
    },
    setOpenDeleteDailog : (state , action) => {
      state.openDeleteDailog = action.payload
    },
    setView : (state, action) => {
        state.viewProduct = action.payload
    },
    setProductDetail : (state,action) => {
          state.productDetail = action.payload
    },
    setEditRow : (state, action) => {
        state.editRow = action.payload
    },
    setDeleteRow : (state, action) => {
        state.deleteRow = action.payload
    },
    setFilterValue: (state, action) => {
      state.filteredItem = action.payload;
      const selectedCategory = action.payload.toLowerCase();
      if (selectedCategory === "all") {
        state.filterValue = state.productList;
        state.productTableList = state.productList
      } else {
        const filterValue = state.productList.filter(
          (item) => item.category.toLowerCase() === selectedCategory
        );
        state.filterValue = filterValue
        state.productTableList = filterValue
      }
    },
    setSearch : (state, action) => {
        state.searchValue = action.payload
        const searchTerm = action.payload.toLowerCase();
        const filteredData = state.filterValue.filter((item:any) =>
        item.title.toLowerCase().includes(searchTerm) ||
        item.description.toLowerCase().includes(searchTerm) ||
        item.category.toLowerCase().includes(searchTerm) ||
        item.price.toString().toLowerCase().includes(searchTerm)
    );
      state.productTableList = filteredData;
    }
  },
  extraReducers: (builder) => {
    builder.addCase(fetchProduct.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchProduct.fulfilled, (state , action) => {
      state.loading = false ;
      state.productList = action.payload as Product[];
      state.productTableList = action.payload as Product[];
      state.filterValue = action.payload as Product[]
      state.filteredItem = 'All'
    });
    builder.addCase(fetchProduct.rejected, (state) => {
      state.loading = false ;
    });
    builder.addCase(login.pending, (state) => {
      state.loading = true ;
    });
    builder.addCase(login.fulfilled, (state) => {
      state.loading = false ;
    });
    builder.addCase(login.rejected, (state) => {
      state.loading = false ;
    });
  }
});

export const { setLoading, setDrawer, setEditRow , setDeleteRow , setOpenDeleteDailog , setSearch, setFilterValue, setView , setProductDetail} = productListSlice.actions;

export default productListSlice.reducer;
