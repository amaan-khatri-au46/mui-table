import  ProductLanding  from "./ProductLanding";

export default ProductLanding;