import React from "react";
import ProductCarousal from "../../components/ProductCarousal";
import Header from "../../components/Header";

const ProductLanding = () => {
  return (
    <div>
      <Header />
      <ProductCarousal />
    </div>
  );
};

export default ProductLanding;
