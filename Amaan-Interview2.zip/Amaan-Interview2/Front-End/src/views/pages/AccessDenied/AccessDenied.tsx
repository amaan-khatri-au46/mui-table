import React from "react";

const AccessDenied = () => {
  return (
    <div>
      <h1>Access Denied</h1>
    </div>
  );
};

export default AccessDenied;
