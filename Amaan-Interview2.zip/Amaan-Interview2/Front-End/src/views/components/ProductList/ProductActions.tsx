import { useRef, useState } from "react";
import { HiOutlinePlusCircle } from "react-icons/hi";
import { useAppDispatch, useAppSelector } from "../../../store/store";
import {
  Button,
  FormControl,
  IconButton,
  Input,
  InputAdornment,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import {
  setDrawer,
  setEditRow,
  setFilterValue,
  setSearch,
} from "../../../store/slices/productSlice";
import { Options } from "../../../utils/commonFunction/common";
import { HiOutlineSearch } from "react-icons/hi";
import { GridSearchIcon } from "@mui/x-data-grid";

export const ProductActions = () => {
  const { filteredItem, searchValue } = useAppSelector(
    (state) => state.product
  );

  const inputRef = useRef(null);

  const dispatch = useAppDispatch();
  const handleInputChange = (event: any) => {
    dispatch(setSearch(event.target.value));
  };

  const handleFilterChange = (event: any) => {
    dispatch(setFilterValue(event.target.value));
    dispatch(setSearch(""));
  };

  return (
    <div className="lg:flex items-center justify-between mx-4 mt-4 mb-6">
      <div className="flex items-center gap-2 text-2xl font-bold">
        <h4>Product</h4>
      </div>
      <div style={{ display: "flex" }}>
        <div style={{ marginRight: "2%" }} className="flex">
          <TextField
            onChange={handleInputChange}
            value={searchValue}
            inputRef={inputRef}
            variant="outlined"
            size="small"
            fullWidth
            placeholder="Search..."
            InputProps={{
              endAdornment: (
                <InputAdornment position="end">
                  <IconButton>
                    <GridSearchIcon />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
        </div>
        <div className="mr-2" style={{ width: "200px" }}>
          <FormControl fullWidth>
            <Select
              value={filteredItem}
              size="small"
              onChange={handleFilterChange}
              MenuProps={{
                PaperProps: {
                  style: {
                    maxHeight: 200,
                    overflowY: "auto",
                  },
                },
              }}
            >
              {Options.map((option) => (
                <MenuItem key={option.value} value={option.value}>
                  {option.label}
                </MenuItem>
              ))}
            </Select>
          </FormControl>
        </div>
        <Button
          variant="contained"
          style={{ width: "100px" }}
          startIcon={<HiOutlinePlusCircle />}
          onClick={() => {
            dispatch(setDrawer(true));
            dispatch(setEditRow([]));
          }}
        >
          Add
        </Button>
      </div>
    </div>
  );
};
