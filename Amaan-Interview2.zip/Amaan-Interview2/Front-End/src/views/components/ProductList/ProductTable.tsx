import React, { useEffect, useMemo } from "react";
import { useAppDispatch, useAppSelector } from "../../../store/store";
import { DataGrid } from "@mui/x-data-grid";
import {
  fetchProduct,
  setDeleteRow,
  setDrawer,
  setEditRow,
  setOpenDeleteDailog,
  setProductDetail,
  setView,
} from "../../../store/slices/productSlice";
import { CiEdit, CiTrash } from "react-icons/ci";
import { BsFillEyeFill } from "react-icons/bs";

const ProductTable = () => {
  const dispatch = useAppDispatch();
  const { productTableList, loading } = useAppSelector(
    (state) => state.product
  );

  const rowsWithIds = productTableList.map((row, index) => ({
    ...row,
    id: index + 1,
    serialNumber: index + 1,
  }));

  useEffect(() => {
    dispatch(fetchProduct());
  }, [dispatch]);

  const columns = useMemo(
    () => [
      {
        field: "serialNumber",
        headerName: "#",
        width: 100,
        renderCell: (params: any) => (
          <div style={{ textAlign: "center" }}>{params.value}</div>
        ),
      },
      {
        field: "title",
        headerName: "Product Title",
        width: 200,
        renderCell: (params: any) => (
          <div style={{ textAlign: "center" }}>{params.value}</div>
        ),
      },
      {
        field: "price",
        headerName: "Product Price",
        width: 200,
        renderCell: (params: any) => (
          <div style={{ textAlign: "center" }}>{params.value}</div>
        ),
      },
      {
        field: "description",
        headerName: "Product Description",
        width: 300,
        renderCell: (params: any) => (
          <div style={{ textAlign: "center" }}>{params.value}</div>
        ),
      },
      {
        field: "category",
        headerName: "Product Category",
        width: 200,
        renderCell: (params: any) => (
          <div style={{ textAlign: "center" }}>{params.value}</div>
        ),
      },
      {
        field: "actions",
        headerName: "Action",
        width: 120,
        renderCell: (params: any) => (
          <div className="flex justify-center w-full">
            <div className="w-1/3 text-center " style={{ cursor: "pointer" }}>
              <button
                onClick={() => {
                  dispatch(setView(true));
                  dispatch(setProductDetail(params.row));
                }}
              >
                <BsFillEyeFill style={{ fontSize: "16px" }} />
              </button>
            </div>
            <div className="w-1/3 text-center">
              <button
                onClick={() => {
                  dispatch(setDrawer(true));
                  dispatch(setEditRow(params.row));
                }}
              >
                <CiEdit style={{ fontSize: "16px" }} />
              </button>
            </div>
            <div className="w-1/3 text-center cursor-pointer">
              <button
                onClick={() => {
                  dispatch(setDeleteRow(params.row));
                  dispatch(setOpenDeleteDailog(true));
                }}
              >
                <CiTrash style={{ fontSize: "16px" }} />
              </button>
            </div>
          </div>
        ),
      },
    ],
    [dispatch]
  );

  return (
    <div style={{ height: "90vh" }}>
      <DataGrid loading={loading} rows={rowsWithIds} columns={columns} />
    </div>
  );
};

export default ProductTable;
