import React from "react";
import { Dialog, IconButton } from "@mui/material";
import { HiX } from "react-icons/hi";
import { setView } from "../../../store/slices/productSlice";
import { useAppDispatch, useAppSelector } from "../../../store/store";

const ProductView = () => {
  const dispatch = useAppDispatch();

  const handleClose = () => {
    dispatch(setView(false));
  };

  const { viewProduct, productDetail }: any = useAppSelector(
    (state) => state.product
  );

  return (
    <Dialog
      open={viewProduct}
      onClose={handleClose}
      style={{ padding: "20px" }}
    >
      <div className="p-12">
        <IconButton
          edge="end"
          color="inherit"
          onClick={handleClose}
          aria-label="close"
          sx={{ position: "absolute", top: 0, right: 12 }}
        >
          <HiX style={{ fontSize: "18px" }} />
        </IconButton>
        <div className="p-4">
          <h2 className="text-xl font-bold mb-2">
            Product Name: {productDetail.title}
          </h2>
          <h2 className="text-xl font-bold mb-2">Product Details</h2>
          <p className="text-gray-700 mb-2">
            <strong>Category:</strong> {productDetail.category}
          </p>
          <p className="text-gray-700 mb-2">
            <strong>Price:</strong> {productDetail.price}
          </p>
          <p className="text-gray-700 mb-4">
            <strong>Description:</strong> {productDetail.description}
          </p>
        </div>
      </div>
    </Dialog>
  );
};

export default ProductView;
