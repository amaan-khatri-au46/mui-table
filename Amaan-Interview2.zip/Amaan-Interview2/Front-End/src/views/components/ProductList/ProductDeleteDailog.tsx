import React from "react";
import {
  Button,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
} from "@mui/material";
import { useAppDispatch, useAppSelector } from "../../../store/store";
import {
  deleteProduct,
  setOpenDeleteDailog,
} from "../../../store/slices/productSlice";
import useToastify from "../../../utils/hooks/useToastify";

const ProductDeleteDialog = () => {
  const dispatch = useAppDispatch();
  const showToast = useToastify();

  const { openDeleteDailog, loading, deleteRow }: any = useAppSelector(
    (state) => state.product
  );

  const handleClose = () => {
    dispatch(setOpenDeleteDailog(false));
  };

  const handleDelete = async () => {
    await dispatch(deleteProduct(deleteRow?._id));
    handleClose();
    showToast("Product Deleted Successfully", "success");
  };

  return (
    <Dialog open={openDeleteDailog} onClose={handleClose} maxWidth="xl">
      <DialogTitle>Delete Product</DialogTitle>
      <DialogContent>
        <p>
          Are you sure you want to delete this Product{" "}
          <b>{deleteRow?.title} </b> ?
        </p>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="primary" disabled={loading}>
          Cancel
        </Button>
        <Button
          onClick={handleDelete}
          variant="contained"
          color="success"
          disabled={loading}
        >
          Delete
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ProductDeleteDialog;
