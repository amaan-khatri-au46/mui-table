import {
  Button,
  Drawer,
  MenuItem,
  Select,
  TextField,
  Typography,
} from "@mui/material";
import React from "react";
import { useAppDispatch, useAppSelector } from "../../../store/store";
import {
  createProduct,
  editProduct,
  setDrawer,
} from "../../../store/slices/productSlice";
import { Field, Form, Formik } from "formik";
import * as Yup from "yup";
import { Options } from "../../../utils/commonFunction/common";
import useToastify from "../../../utils/hooks/useToastify";

const ProductForm = () => {
  const { openDrawer, editRow, loading }: any = useAppSelector(
    (state) => state.product
  );

  const dispatch = useAppDispatch();
  const showToast = useToastify();

  const onDialogClose = () => {
    dispatch(setDrawer(false));
  };

  const validationSchema = Yup.object().shape({
    title: Yup.string().required("Product Title is required"),
    description: Yup.string().required("Product Description is required"),
    price: Yup.number().required("Product Price is required"),
    category: Yup.string().required("Product Category is required"),
  });

  return (
    <Drawer open={openDrawer} onClose={onDialogClose} anchor="right">
      <div style={{ padding: "16px" }}>
        <h2 className="font-bold text-2xl">
          {editRow._id ? "Edit Product" : "Add Product"}
        </h2>
      </div>
      <Formik
        initialValues={{
          title: editRow ? editRow?.title : "",
          description: editRow ? editRow?.description : "",
          price: editRow ? editRow?.price : "",
          category: editRow ? editRow.category : "",
        }}
        validationSchema={validationSchema}
        onSubmit={async (values) => {
          const res = editRow._id
            ? await dispatch(editProduct({ id: editRow?._id, data: values }))
            : await dispatch(createProduct(values));
          console.log(res, "===>");
          showToast(
            editRow._id
              ? "Product Edited  successfully"
              : "Product Added successfully",
            "success"
          );
          await dispatch(setDrawer(false));
        }}
      >
        {({ values, errors, touched, dirty }) => (
          <Form>
            <div style={{ padding: "0px 32px 0px 32px" }}>
              <div className="mt-5" style={{ height: "64px" }}>
                <label htmlFor="title">Title *</label>
                <Field
                  as={TextField}
                  name="title"
                  fullWidth
                  size="small"
                  placeholder="Title"
                  error={!!errors.title && !!touched.title}
                  helperText={errors.title && touched.title && errors.title}
                />
              </div>
              <div className="mt-5" style={{ height: "96px" }}>
                <label htmlFor="description">Description*</label>
                <Field
                  as={TextField}
                  name="description"
                  size="small"
                  fullWidth
                  multiline
                  rows={2}
                  placeholder="Description"
                  error={!!errors.description && !!touched.description}
                  helperText={
                    errors.description &&
                    touched.description &&
                    errors.description
                  }
                />
              </div>
              <div className="mt-4" style={{ height: "64px" }}>
                <label htmlFor="price">Price*</label>
                <Field
                  as={TextField}
                  name="price"
                  type="number"
                  size="small"
                  fullWidth
                  placeholder="Enter the price"
                  error={!!errors.price && !!touched.price}
                  helperText={errors.price && touched.price && errors.price}
                />
              </div>
              <div
                className="mt-5"
                style={{
                  maxHeight: "200px",
                  overflowY: "auto",
                }}
              >
                <label htmlFor="category" className="block font-semibold">
                  Category *
                </label>
                <Field
                  as={Select}
                  name="category"
                  fullWidth
                  size="small"
                  error={!!errors.category && !!touched.category}
                  helperText={
                    errors.category && touched.category && errors.category
                  }
                  style={{ marginTop: "8px" }}
                  MenuProps={{
                    PaperProps: {
                      style: {
                        maxHeight: 200,
                      },
                    },
                  }}
                >
                  {Options.map((option) => (
                    <MenuItem key={option.value} value={option.value}>
                      {option.label}
                    </MenuItem>
                  ))}
                </Field>
              </div>

              <div className="w-full flex gap-2 justify-end mt-6">
                <Button
                  variant="outlined"
                  type="button"
                  onClick={() => dispatch(setDrawer(false))}
                >
                  Cancel
                </Button>
                <Button
                  variant="contained"
                  type="submit"
                  disabled={loading || !dirty}
                >
                  Submit
                </Button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
    </Drawer>
  );
};

export default ProductForm;
