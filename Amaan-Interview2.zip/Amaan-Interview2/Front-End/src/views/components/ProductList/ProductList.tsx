import React from "react";
import ProductTable from "./ProductTable";
import ProductForm from "./ProductForm";
import { ProductActions } from "./ProductActions";
import ProductDeleteDialog from "./ProductDeleteDailog";
import ProductView from "./ProductView";

const ProductList = () => {
  return (
    <div>
      <ProductDeleteDialog />
      <ProductView />
      <ProductForm />
      <ProductActions />
      <ProductTable />
    </div>
  );
};

export default ProductList;
