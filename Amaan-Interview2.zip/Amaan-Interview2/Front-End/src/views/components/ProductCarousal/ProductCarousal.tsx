import React, { useRef } from "react";
import Slider from "react-slick";
import { RiArrowLeftSLine, RiArrowRightSLine } from "react-icons/ri";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { generateProductImages } from "../../../utils/commonFunction/common";

const ProductCarousal = () => {
  const productImages = generateProductImages(12);
  const sliderRef: any = useRef(null);

  const settings = {
    dots: false,
    infinite: true,
    speed: 900,
    slidesToShow: 3,
    slidesToScroll: 1,
    centerMode: true,
    centerPadding: "60px",
  };

  const prevSlide = () => {
    sliderRef.current.slickPrev();
  };

  const nextSlide = () => {
    sliderRef.current.slickNext();
  };

  return (
    <div style={{ backgroundColor: "#f5e9d4", padding: "40px" }}>
      <div className="flex justify-center flex-col items-center">
        <h4
          style={{
            fontFamily: "Breasto",
            fontSize: "24px",
            fontWeight: "lighter",
          }}
        >
          PACKAGING AS UNIQUE AS YOUR EMOTIONS,
        </h4>
        <h4
          style={{
            fontFamily: "Breasto",
            fontSize: "24px",
            fontWeight: "lighter",
          }}
        >
          RELATIONS AND CONNECTIONS!
        </h4>
      </div>

      <div className="relative mt-36">
        <Slider ref={sliderRef} {...settings}>
          {productImages.map((imageUrl, index) => (
            <div key={index}>
              <div className="max-w-xs mx-auto rounded-lg overflow-hidden shadow-lg">
                <img
                  src={imageUrl}
                  alt={`Product ${index + 1}`}
                  className="w-full h-48 object-cover"
                />
              </div>
            </div>
          ))}
        </Slider>
        <div className="absolute bottom-24 left-0 right-0 flex justify-between px-4">
          <button
            style={{ border: "none", background: "none" }}
            className=" px-3 py-1 rounded-full"
            onClick={prevSlide}
          >
            <RiArrowLeftSLine className="text-4xl" />
          </button>
          <button
            style={{ border: "none", background: "none" }}
            className="border-none px-3 py-1 rounded-full"
            onClick={nextSlide}
          >
            <RiArrowRightSLine className="text-4xl" />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCarousal;
