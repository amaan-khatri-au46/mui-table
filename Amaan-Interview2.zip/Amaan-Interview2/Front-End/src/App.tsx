import { BrowserRouter, Routes, Route } from "react-router-dom";
import Register from "./views/pages/Register";
import ProtectedRoute from "./utils/auth";
import { Provider } from "react-redux";
import store from "./store/store";
import AccessDenied from "./views/pages/AccessDenied";
import Home from "./views/pages/Home";
import Login from "./views/pages/Login";
import ProductLanding from "./views/pages/ProductLanding";

const App = () => {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<ProtectedRoute />}>
            <Route path="/" element={<Home />} />
            <Route path="/product" element={<ProductLanding />} />
          </Route>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="*" element={<AccessDenied />} />
        </Routes>
      </BrowserRouter>
    </Provider>
  );
};

export default App;
